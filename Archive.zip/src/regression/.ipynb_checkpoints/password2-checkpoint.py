import ipywidgets as widgets
from IPython.display import display, clear_output

def password2():
    richtiges_passwort = ["MachineLearning", "Machine Learning", "Machine-Learning", "machinelearning", "machine learning", "machine-learning", "MACHINELEARNING", "MACHINE LEARNING", "MACHINE-LEARNING"]
    
    # Passwortfeld (versteckt)
    passwort_eingabe = widgets.Password(
        description='Passwort:',
        placeholder='Passwort eingeben'
    )
    
    # Checkbox zum Passwort anzeigen/verstecken
    show_passwort = widgets.Checkbox(
        value=False,
        description='Passwort anzeigen'
    )
    
    # Button zum Bestätigen
    bestaetigen = widgets.Button(description="Bestätigen")
    
    # Ausgabe-Widget für Rückmeldung
    output = widgets.Output()
    
    def toggle_password_visibility(change):
        if change['new']:
            visible_pass = widgets.Text(
                value=passwort_eingabe.value,
                description='Passwort:',
                placeholder='Passwort eingeben'
            )
            def on_visible_change(change):
                passwort_eingabe.value = change['new']
            visible_pass.observe(on_visible_change, names='value')
            
            box.children = (visible_pass, show_passwort, bestaetigen, output)
            password_widget_map['field'] = visible_pass
            
        else:
            box.children = (passwort_eingabe, show_passwort, bestaetigen, output)
            password_widget_map['field'] = passwort_eingabe
    
    def pruefe_passwort(b):
        with output:
            clear_output()
            pw = password_widget_map['field'].value
            if pw in richtiges_passwort:
                display(widgets.HTML(value='''
                    <span style="color:green; font-weight:bold;">Passwort korrekt! Zugriff gewährt.</span>
                    <div style="display: flex; justify-content: center; gap: 8px; margin: 24px 0;">
                      <a href="story_game_2.ipynb" style="
                        padding: 10px 24px;
                        border-radius: 8px;
                        border: 2px solid #3c763d;
                        background-color: #3c763d;
                        color: white;
                        text-decoration: none;
                        font-weight: bold;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                      ">In den Serverraum &nbsp;<i class="fa fa-arrow-right"></i></a>
                    </div>
                '''))
            else:
                display(widgets.HTML(value='<span style="color:red; font-weight:bold;">Falsches Passwort! Zugriff verweigert.</span>'))
    
    show_passwort.observe(toggle_password_visibility, names='value')
    bestaetigen.on_click(pruefe_passwort)
    
    password_widget_map = {'field': passwort_eingabe}
    box = widgets.VBox([passwort_eingabe, show_passwort, bestaetigen, output])
    display(box)
